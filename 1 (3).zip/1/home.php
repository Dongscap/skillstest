<?php 
     include ("db.php");
     $header = ["SID","LASTNAME","FIRSTNAME","COURSE","YEAR","STATUS"];

     $rows = getall();   
     $sid;
     $flag = false;
     $getstud;

     if(isset($_GET['search'])){
          $sid = $_GET['SEARCH'];

          if(!empty(trim($sid))){
               $getstud = getstudent($sid);
               $flag = true;
          }else{
               header("location:home.php");
          }     
     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>HOME</title>
</head>
<body>

     <form method = "GET" action="home.php">
          <a href="add.php">ADD</a>
          <input type="search" name="SEARCH">
          <button type="submit" name="search" value="search">SEARCH</button>
     </form>
     <table>
          <tr>
               <?php 
                    foreach($header as $head){
                         echo "<th>$head</th>";
                    }
               ?>
          </tr>

          <?php
               if(!$flag){
                    while($row = mysqli_fetch_assoc($rows)){
                         echo "
                              <tr>
                                   <td>".$row['sid']."</td>
                                   <td>".$row['lastname']."</td>
                                   <td>".$row['firstname']."</td>
                                   <td>".$row['course']."</td>
                                   <td>".$row['year']."</td>
                                   <td>
                                        <a href='delete.php?sid=".$row['sid']."'>DELETE</a>
                                        <a href='edit.php?sid=".$row['sid']."'>EDIT</a>
                                   </td>
                              </tr>
                         ";
                    }
               }else{
                    if (count($getstud) > 0 ) {
                         foreach($getstud as $row){
                       echo "
                         <tr>
                         <td>".$row['0']."</td>
                         <td>".$row['1']."</td>
                         <td>".$row['2']."</td>
                         <td>".$row['3']."</td>
                         <td>".$row['4']."</td>
                         <td>
                              <a href='delete.php?sid=".$row['0']."'>DELETE</a>
                              <a href='edit.php?sid=".$row['0']."'>EDIT</a>
                              <a href='home.php'>BACK</a>
                         </td>
                          </tr>
                   ";}
                    }else{
                         echo "
                              <tr>
                                   <td colspan=6>NO RECORD FOUND <a href='home.php'>BACK</a></td>
                                   
                              </tr>
                         ";
                    }						
              }       
          ?>
     </table>
</body>
</html>
<style>
     table{
          width:100%;
          margin:0 auto;
          border-collapse:collapse;
          text-align:center;
     }
     tr, th, td{
          border:1px solid black;
          padding:10px;
     }
     button{
          padding:5px;
          margin-bottom:5px;
     }
     a{
          padding: 5px;
          text-decoration: none;
          color:black;
          border:1px solid black;
     }
     input{
          padding:5px;
          width:20%;
     }
</style>   
