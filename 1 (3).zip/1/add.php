<?php 
     include ('db.php');

     $sid;
     $lastname;
     $firstname;
     $course;
     $year;

     if(isset($_GET['ADD'])){
        $sid = $_GET['SID'];
        $lastname = $_GET['LASTNAME'];
        $firstname = $_GET['FIRSTNAME'];
        $course = $_GET['COURSE'];
        $year = $_GET['YEAR'];
        
        if(empty(getstudent($sid))){
            if($sid != null && $lastname != null && $firstname != null && $course != null && $year != null){
                    addstudent($sid,$lastname,$firstname,$course,$year);
            }
        }
        header("location:home.php");

     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD STUDENT</title>
</head>
<body>
    <form index="add.php" method="GET">

        <label for = "SID">Student ID</label>
        <input type="number" name ="SID">

        <label for = "LASTNAME">LASTNAME</label>
        <input type="text" name = "LASTNAME">

        <label for = "FIRSTNAME">FIRSTNAME</label>
        <input type="text" name = "FIRSTNAME">

        <label for = "COURSE">COURSE</label>
        <input type="text" name = "COURSE">

        <label for = "YEAR">YEAR</label>
        <input type="text" name = "YEAR">

        <button type="submit" name="ADD" value="ADD">ADD</button>
    </form>
</body>
</html>