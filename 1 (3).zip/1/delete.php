<?php 
    include ("db.php");

    $sid = $_GET['sid'];
    
    deletestudent($sid);
    header("location:home.php");
?>
