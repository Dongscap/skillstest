<?php 
    include 'db.php';
    $lastname;
    $firstname;
    $course;
    $year;
    //get id from url
    $sid = $_GET['sid'];
	$getstud = getstudent($sid);
	if (isset($_POST['EDIT'])){
        $lastname = $_POST['LASTNAME'];
		$firstname = $_POST['FIRSTNAME'];
		$course = $_POST['COURSE'];
		$year = $_POST['YEAR'];		
		editstudent($sid, $lastname, $firstname, $course, $year);
		header("location:home.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT STUDENT</title>
</head>
<body>
    <form action="edit.php?sid=<?php echo $sid; ?>" method="POST">
        <?php foreach($getstud as $row){ ?>
        <label for = "ID">ID</label>
        <input type="number" name="sid" value="<?php echo $row['0']; ?>" disabled/> 

        <label for = "LASTNAME">lastname</label>
        <input type= "text" name ="LASTNAME" value="<?php echo $row['1']; ?>"required/>

        <label for = "FIRSTNAME">Firstname</label>
        <input type= "text" name ="FIRSTNAME" value="<?php echo $row['2']; ?>" required/>

        <label for = "COURSE">Course</label>
        <input type= "text" name ="COURSE" value="<?php echo $row['3']; ?>" required/>
        <label for = "YEAR">Year</label>
        <input type= "text" name ="YEAR" value="<?php echo $row['4']; ?>" required/>
        <?php } ?>  
        <button type ="submit" name = "EDIT" value = "EDIT">EDIT</button>
    </form>
</body>
</html>
