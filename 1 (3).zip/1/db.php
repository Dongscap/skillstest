<?php 
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "1";

    $conn;

    function connect(){
        global $hostname,$username,$password,$database,$conn;
        $conn = mysqli_connect($hostname,$username,$password,$database);
    }

    function diconnect(){
        global $conn;
        mysqli_close($conn);
    }

    function login($user,$pass){
        global $conn;
        connect();
        $query = mysqli_query($conn,"SELECT * FROM `account` where `user` = '$user' and `pass` = '$pass'");
        diconnect();

        return $query;
    }

    function getall(){
        global $conn;
        connect();
        $query = mysqli_query($conn,"SELECT * FROM `student`");
        diconnect();  

        return $query;
    }

    function getstudent($sid){
        global $conn;
        connect();
        $query = mysqli_query($conn,"SELECT * FROM `student` where `sid` = $sid");
        $rows = mysqli_fetch_all($query);
        diconnect(); 
        
        return $rows;
    }
    
    function addstudent($sid,$lastname,$firstname,$course,$year){
        global $conn;
        connect();
        $query = mysqli_query($conn,"INSERT into `student` values($sid,'$lastname','$firstname','$course','$year')");
        diconnect();
    }

    function deletestudent($sid){
        global $conn;
        connect();
        $query = mysqli_query($conn,"DELETE from `student` where `sid` = $sid");
        diconnect();
    }

    function editstudent($sid,$lastname,$firstname,$course,$year){
        global $conn;
        connect();
        $query = mysqli_query($conn,"UPDATE `student` SET `lastname` = '$lastname', `firstname` = '$firstname', `course` = '$course', `year` = '$year' where `sid` = $sid");
        diconnect();
    }
?>